# Data-Manipulation-and-Plotting

In this project, Several input data are used to train and test data are used for testing using different algorithms such as K-Means clustering, KNN, Perceptron and so forth. Moreover, Data are plotted to figure out the result of test data in comparison with train data in an organized way.

1. Minimum distance to class mean - It has classified test datasets to its desired classes according to train datasets considering minimum distance.

2. K-means clustering - Datasets are clustered successfully according to K-means clustering algorithm.

3. KNN - Datasets are classified accurately based on KNN algorithm while user can input the nearest neighbor count so that datasets are classified according to the nearest neighbor number which user give inputs.

4. Minimum error rate classifier - A minimum error rate classifier for a two class problem with given data has been designed considering they follow normal distribution.

5. Perceptron Algorithm - Algorithm solved for batch processing(Many at a time) and single processing(One at a time) and result showed in graph.
